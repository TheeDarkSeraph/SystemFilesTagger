﻿namespace FileTagEF {
    public class Class1 {

    }
}
